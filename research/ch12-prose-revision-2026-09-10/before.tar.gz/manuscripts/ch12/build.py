#!/usr/bin/env python3
"""Build source-linked figures and a self-contained chapter 12 reading edition."""
from pathlib import Path
from fractions import Fraction
import argparse, base64, hashlib, html, json, re, subprocess
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import markdown
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--font');args=parser.parse_args()
font=next((Path(p) for p in [args.font,'/System/Library/Fonts/Supplemental/Arial Unicode.ttf','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'] if p and Path(p).exists()),None)
if font is None:raise SystemExit('Install a CJK font or pass --font')
font_manager.fontManager.addfont(str(font));family=font_manager.FontProperties(fname=str(font)).get_name()
plt.rcParams.update({'font.family':family,'font.size':11,'axes.unicode_minus':False,'svg.fonttype':'none','svg.hashsalt':'ch12-edge-v1','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','savefig.facecolor':'white','text.color':'#203c48','axes.labelcolor':'#203c48','pdf.fonttype':42})
C={'ink':'#203c48','blue':'#286b98','teal':'#16857b','orange':'#bc722b','red':'#a94c52','pale':'#eef4f7','light':'#eaf5f1','sand':'#fbf0e5','line':'#c3d0d7','muted':'#546e7a'}
for x in json.loads((HERE/'sources.json').read_text())['sources']:
 if hashlib.sha256((ROOT/x['path']).read_bytes()).hexdigest()!=x['sha256']:raise SystemExit('Review changed source: '+x['path'])
def calc(name):return json.loads((ROOT/'calculations/results'/f'{name}.json').read_text())
def num(v):
 if isinstance(v,dict) and 'numerator' in v:return v['numerator']/v['denominator']
 return float(Fraction(str(v)))
outputs=[];data={};layout=[]
def save(f,name):
 f.canvas.draw();renderer=f.canvas.get_renderer()
 for t in f.findobj(matplotlib.text.Text):
  if not t.get_visible() or not t.get_text():continue
  if re.search(r'图\s*\d+\s*[-－–]\s*\d+',t.get_text()):raise ValueError('Figure number inside artwork')
  b=t.get_window_extent(renderer)
  # Include only painted tick labels within the active coordinate range.
  if b.x0<0 or b.y0<0 or b.x1>f.bbox.width or b.y1>f.bbox.height:layout.append({'figure':name,'text':t.get_text(),'bbox':[round(v,2) for v in b.bounds]})
 for ext in ['svg','png','pdf']:
  p=HERE/(name+'.'+ext);f.savefig(p,dpi=180,bbox_inches='tight',pad_inches=.15);outputs.append(p)
 plt.close(f)
def canvas(height=8):
 f,a=plt.subplots(figsize=(13,height));f.subplots_adjust(left=.025,right=.975,top=.97,bottom=.04);a.set(xlim=(0,1),ylim=(0,1));a.axis('off');return f,a
def box(a,x,y,w,h,title,body='',col='pale',size=12):
 a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.004,rounding_size=0.008',ec=C['line'],fc=C[col],lw=1.1))
 a.text(x+w/2,y+h*(.70 if body else .50),title,ha='center',va='center',fontsize=size,weight='bold')
 if body:a.text(x+w/2,y+h*.27,body,ha='center',va='center',fontsize=10,linespacing=1.4,color=C['muted'])
def arrow(a,p,q,col='teal',rad=0,lw=1.6):a.add_patch(FancyArrowPatch(p,q,arrowstyle='-|>',mutation_scale=13,lw=lw,color=C[col],connectionstyle=f'arc3,rad={rad}'))
def panel(a,x,y,t):a.text(x,y,t,fontsize=14,weight='bold',va='top')
# 1: All arithmetic in this panel is an explicitly declared teaching scenario.
f,axs=plt.subplots(1,2,figsize=(13,5.8));f.subplots_adjust(left=.105,right=.97,bottom=.22,top=.88,wspace=.42)
vals=np.array([[12,.1,.3,.4,0],[12,.1,.03,.4,0],[6,.1,.3,.4,.15]])
a=axs[0];left=np.zeros(3)
for j,(label,c) in enumerate([('上传','blue'),('传播','muted'),('处理','teal'),('下载','orange'),('额外编解码','red')]):
 a.barh(np.arange(3),vals[:,j],left=left,label=label,color=C[c],height=.48);left+=vals[:,j]
a.set(yticks=range(3),yticklabels=['原方案','处理十倍加速','假定无损压缩'],xlabel='完整成片时间 / s',xlim=(0,14.7));a.invert_yaxis();a.set_title('同一任务的三种修改',loc='left',fontsize=13)
for i,v in enumerate(left):a.text(v+.12,i,f'{v:.2f}',va='center',fontsize=10)
a.legend(frameon=False,ncol=3,fontsize=9,loc='upper left',bbox_to_anchor=(-.18,-.15))
bw=np.geomspace(5,200,160);a=axs[1]
for label,y,c in [('原方案',240/bw+.8,'blue'),('处理十倍加速',240/bw+.53,'teal'),('假定无损压缩',120/bw+.95,'red')]:a.plot(bw,y,color=C[c],lw=2,label=label)
a.set(xscale='log',xlabel='上行速率 / Mbit/s',ylabel='完整成片时间 / s',ylim=(0,51));a.set_xticks([5,10,20,50,100,200],['5','10','20','50','100','200']);a.set_yticks([0,10,20,30,40,50]);a.grid(alpha=.18);a.legend(frameon=False,fontsize=9);a.set_title('上行改变后的收益',loc='left',fontsize=13)
save(f,'figure-12-1-raw');data['12-1']={'kind':'teaching','input_MB':30,'output_MB':5,'down_Mbps':100,'rtt_s':.1,'stages_s':vals.tolist(),'uplink_Mbps':bw.tolist(),'base_s':(240/bw+.8).tolist(),'compressed_s':(120/bw+.95).tolist()}
# 2: Three distinct completion semantics plus directly saved audio events.
f,a=canvas(10)
rows=[(.81,'整项交付',[('原图','30 MB'),('上传','完整输入到达'),('精修与编码','完整成片生成'),('下载与显示','5 MB')]),(.56,'持续流水',[('采集／文本','按接口就绪'),('ASR / TTS','按实际粒度输出'),('传输与缓冲','每块有到达时刻'),('持续播放','首次可用＋停顿')]),(.31,'多轮闭环',[('截图 v','当前界面'),('编码与上传','保持必要信息'),('模型判断','依赖截图版本'),('操作与更新','确认后进入下一轮')])]
for y,label,items in rows:
 panel(a,.015,y+.15,label)
 for i,(t,b) in enumerate(items):
  x=.17+i*.207;box(a,x,y,.182,.13,t,b,size=11)
  if i<3:arrow(a,(x+.185,y+.064),(x+.204,y+.064))
# The feedback edge travels outside all boxes.
a.plot([.883,.883,.26,.26],[.31,.265,.265,.30],color=C['teal'],lw=1.6);arrow(a,(.26,.28),(.26,.31));a.text(.54,.235,'下一轮必须取得操作后的有效观察',ha='center',fontsize=10,color=C['teal'])
ax=f.add_axes([.19,.055,.75,.14]);chunks=calc('audio-timing-base')['audio_chunks']
for i,z in enumerate(chunks[:5]):
 y=4-i;ax.scatter(z['arrival_ns']/1e6,y,color=C['blue'],s=28,zorder=3)
 ax.broken_barh([(z['playback_start_ns']/1e6,20)],(y-.18,.36),facecolors=C['teal'])
 ax.scatter(z['deadline_ns']/1e6,y,marker='|',s=120,color=C['orange'],zorder=4)
ax.plot([],[],marker='o',ls='',color=C['blue'],label='到达');ax.plot([],[],lw=7,color=C['teal'],label='实际播放');ax.plot([],[],marker='|',ls='',color=C['orange'],label='原定播放')
ax.set(yticks=range(5),yticklabels=['块 5','块 4','块 3','块 2','块 1'],xlabel='教学流水时刻 / ms',xlim=(25,185));ax.set_xticks([40,60,80,100,120,140,160,180]);ax.legend(frameon=False,fontsize=9,ncol=3,loc='upper right',bbox_to_anchor=(1,1.35));ax.grid(axis='x',alpha=.15)
save(f,'figure-12-2-paths');data['12-2']={'kind':'dependency_diagram_and_saved_teaching_events','audio_source':'calculations/results/audio-timing-base.json','audio_chunks':chunks}
# 3: Representation boundaries; logarithmic scale prevents KV hiding the input.
f,a=canvas(9)
for y,label,items in [(.77,'整项远程调用',[('端侧','采集与压缩'),('跨设备：图片','0.8 MB'),('远端','编码＋语言推理')]),(.56,'端侧编码',[('端侧','采集＋视觉编码'),('跨设备：完整 EC','7.8125 MiB'),('远端','语言推理')]),(.35,'会话迁移',[('源设备','停止／提交状态'),('跨设备：兼容状态','KV＋任务／环境'),('目的设备','恢复后继续多轮')])]:
 panel(a,.015,y+.145,label)
 for i,(t,b) in enumerate(items):
  x=.19+i*.27;box(a,x,y,.235,.125,t,b,col='light' if i==1 else 'pale',size=11)
  if i<2:arrow(a,(x+.24,y+.063),(x+.263,y+.063))
ax=f.add_axes([.19,.08,.70,.21]);ec=calc('multimodal-cache-single')['summary'];sizes=[800000,ec['complete_encoder_bytes_per_image'],ec['visual_kv_bytes_per_image']]
ax.barh([2,1,0],np.array(sizes)/1e6,color=[C['blue'],C['teal'],C['orange']],height=.52);ax.set(xscale='log',xlim=(.3,150),yticks=[2,1,0],yticklabels=['压缩图片','完整视觉 EC','视觉位置的 KV'],xlabel='数据量 / MB（十进制，对数刻度）');ax.set_xticks([.5,1,5,10,50,100],['0.5','1','5','10','50','100'])
for y,size in zip([2,1,0],sizes):ax.text(size/1e6*1.10,y,f'{size/1e6:g} MB',va='center',fontsize=10)
save(f,'figure-12-3-placement');data['12-3']={'kind':'fixed_model_shape_and_teaching_input','source':'calculations/results/multimodal-cache-single.json','bytes':sizes,'uplink_seconds_at_6_4Mbps':[x*8/6.4e6 for x in sizes],'complete_shape':[400,10240]}
# 4: Independent contrasts, never a cumulative optimization waterfall.
f,a=canvas(8.8);panel(a,.015,.97,'准备、发送与完成是三个不同事件')
for y,label,items in [(.75,'首次连接',[('建立安全上下文','握手与验证'),('发送请求','窗口与服务供给'),('接收结果','应用检查完成')]),(.53,'已有连接',[('复用已有状态','仍需检查路径／额度'),('发送请求','不是零传播'),('接收结果','不是零处理')])]:
 a.text(.015,y+.055,label,fontsize=12)
 for i,(t,b) in enumerate(items):
  x=.18+i*.27;box(a,x,y,.235,.14,t,b,size=11)
  if i<2:arrow(a,(x+.24,y+.07),(x+.263,y+.07))
comp={}
for pos,(files,title,labels) in enumerate([(['shared-media-schedule-fifo','shared-media-schedule-priority'],'只改发送顺序',['FIFO','音频优先']),(['shared-media-hol-connection','shared-media-hol-per_stream'],'固定发送，只改交付顺序',['整体有序','逐流交付'])]):
 ax=f.add_axes([.10+pos*.48,.12,.36,.26]);ys=[]
 for name in files:
  b={z['id']:num(z['complete']) for z in calc(name)['businesses']};ys.append([b['image'],b['audio']])
 vals=np.array(ys);x=np.arange(2)
 for j,(lab,c) in enumerate([('图片','blue'),('音频','orange')]):
  bars=ax.barh(x+(j-.5)*.30,vals[:,j],height=.28,color=C[c],label=lab)
  for b in bars:ax.text(b.get_width()+.08,b.get_y()+.14,f'{b.get_width():g}',va='center',fontsize=10)
 ax.set(yticks=x,yticklabels=labels,xlim=(0,8.4),xlabel='本对照内的完成时间 / s');ax.invert_yaxis();ax.set_title(title,loc='left',fontsize=12);ax.legend(frameon=False,ncol=2,fontsize=9,loc='upper left',bbox_to_anchor=(0,-.26));comp[title]={'sources':files,'rows':labels,'image_audio_seconds':ys}
save(f,'figure-12-4-transport');data['12-4']={'kind':'two_independent_saved_teaching_contrasts','comparisons':comp}
# 5: Exact successful reference exchanges and bounded loopback failure experiment.
air=calc('shared-airtime-image-baseline');services=[]
for kind in ['data','ack']:
 z=next(x for x in air['wireless_attempts'] if x['kind']==kind)['service'];parts=[num(z['access_idle_seconds']),num(z['data_ppdu']['duration']),num(z['mac_ack_start_offset'])-num(z['data_end_offset']),num(z['mac_ack_ppdu']['duration'])];services.append([v*1e6 for v in parts])
del air
f,a=canvas(9.4);panel(a,.015,.97,'数据与端到端 ACK 都需要一次本跳交换')
ax=f.add_axes([.19,.69,.72,.18]);left=np.zeros(2)
for j,(lab,c) in enumerate([('接入空等','muted'),('数据 PPDU','blue'),('SIFS','orange'),('MAC ACK','teal')]):
 vals=np.array(services)[:,j];ax.barh([1,0],vals,left=left,height=.46,color=C[c],label=lab);left+=vals
ax.set(yticks=[1,0],yticklabels=['承载数据','承载端到端 ACK'],xlim=(0,345),xlabel='固定参考交换 / μs')
for y,v in zip([1,0],left):ax.text(v+5,y,f'{v:g}',va='center',fontsize=10)
ax.legend(frameon=False,ncol=4,fontsize=9,loc='upper left',bbox_to_anchor=(0,-.27))
panel(a,.015,.49,'两条接入路径仍可能共享故障点')
box(a,.015,.19,.17,.14,'终端','去重与操作身份',size=11)
box(a,.27,.32,.16,.10,'Wi-Fi',size=11);box(a,.27,.10,.16,.10,'蜂窝',size=11)
box(a,.53,.19,.17,.14,'汇合代理','共享容量／故障',col='sand',size=11);box(a,.80,.19,.17,.14,'服务端','会话与任务状态',col='sand',size=11)
arrow(a,(.19,.285),(.264,.37));arrow(a,(.19,.235),(.264,.15));arrow(a,(.433,.37),(.526,.285));arrow(a,(.433,.15),(.526,.235));arrow(a,(.705,.26),(.793,.26))
a.text(.50,.04,'已有本机双连接：无故障 5/5；主连接关闭 5/5；共同端点关闭 0/5（每种策略）',ha='center',fontsize=11,color=C['muted'])
save(f,'figure-12-5-wireless');data['12-5']={'kind':'reference_airtime_and_separate_loopback_measurement','exchange_components_us':services,'components':['access_idle','data_ppdu','sifs','mac_ack'],'measured_each_strategy_successes':[5,5,0],'trials_each':5,'physical_wireless_measurement':False}
# 6: Original fixed-file matched rows plus a visibly separate later experiment.
q=calc('queqiao-records-conditions');fixed=[x for x in q['same_condition_comparisons'] if x['condition'][:2]==['single-fixed-file','asr_upload']]
matched={x['condition'][2]:x for x in fixed};warm=matched['held_open'];cold=matched['new'];med=np.array([[num(cold['numerator_ms']),num(cold['denominator_ms'])],[num(warm['numerator_ms']),num(warm['denominator_ms'])]])
phys=(ROOT/'experiments/ch12/12-07/audio-physical/README.md').read_text();rows=re.findall(r'^\|([0-3])／(on|off)\|([\d.]+)\|([\d.]+)\|(\d+)\|(\d+)\|$',phys,re.M);assert len(rows)==4
starvation=np.array([[int(r[4]),int(r[5])] for r in rows]);f=plt.figure(figsize=(13,10))
for i,label in enumerate(['新建连接','保持连接并调优']):
 ax=f.add_axes([.10+i*.47,.59,.36,.31]);bars=ax.bar([0,1],med[i],color=[C['blue'],C['teal']],width=.55);ax.set(xticks=[0,1],xticklabels=['直接路径','Queqiao'],ylabel='请求完成 p50 / ms',ylim=(0,1400 if i==0 else 290));ax.set_title(label,loc='left',fontsize=13)
 for b in bars:ax.text(b.get_x()+b.get_width()/2,b.get_height()+(.02*ax.get_ylim()[1]),f'{b.get_height():.1f}',ha='center',fontsize=12)
f.text(.10,.97,'同一固定音频文件；每组内部匹配，组间条件不同',fontsize=14,weight='bold')
ax=f.add_axes([.10,.13,.83,.28]);x=np.arange(4)
for j,(label,c) in enumerate([('TUIC 绑定适配基线','blue'),('Queqiao','teal')]):
 bars=ax.bar(x+(j-.5)*.34,starvation[:,j],width=.31,color=C[c],label=label)
 for b in bars:ax.text(b.get_x()+b.get_width()/2,b.get_height()+28,str(int(b.get_height())),ha='center',fontsize=10)
ax.set(xticks=x,xticklabels=[f'轮 {r[0]}／池 {r[1]}' for r in rows],ylabel='累计回调源不足 / ms',ylim=(0,1820));ax.set_title('另一批音频设备实验：全部字节完整，仍有源不足',loc='left',fontsize=13);ax.legend(frameon=False,ncol=2,loc='upper left',fontsize=10)
f.text(.10,.04,'不同提交、不同负载；静音设备回调，无模型生成和声学测量。',fontsize=10,color=C['muted'])
save(f,'figure-12-6-queqiao');data['12-6']={'kind':'two_separate_recorded_experiments','matched_ASR_ms':med.tolist(),'recorded_fixed_bytes':q['generations']['single-fixed-file']['payload_low_bytes'],'starvation_ms':starvation.tolist(),'physical_rows':rows,'source_documents':['calculations/results/queqiao-records-conditions.json','experiments/ch12/12-07/audio-physical/README.md']}
# 7: New teaching extension of the existing screenshot workload, not empirical prices.
b=np.linspace(4,20,200);cloud=27+128/b;f,axs=plt.subplots(1,2,figsize=(13,6));f.subplots_adjust(left=.08,right=.96,bottom=.20,top=.87,wspace=.32)
ax=axs[0];ax.plot(b,cloud,color=C['blue'],lw=2,label='云地域：27 + 128/b');ax.axhline(41,color=C['teal'],lw=2,label='附近工作站：41 s');ax.axhline(45,color=C['red'],ls='--',label='任务期限：45 s');ax.scatter([128/18,128/14],[45,41],s=40,color=C['orange'],zorder=3);ax.annotate('可满足期限\n7.11 Mbit/s',(128/18,45),(9,52),fontsize=10,arrowprops={'arrowstyle':'->','color':C['muted']});ax.annotate('更快的边界\n9.14 Mbit/s',(128/14,41),(12,44),fontsize=10,arrowprops={'arrowstyle':'->','color':C['muted']});ax.set(xlabel='云路径上行 b / Mbit/s',ylabel='20 轮完整任务时间 / s',xlim=(4,20),ylim=(30,65));ax.legend(frameon=False,fontsize=9,loc='upper right');ax.grid(alpha=.16);ax.set_title('带宽只改变云路径的上传时间',loc='left',fontsize=13)
ax=axs[1];cost=[.060,.080,.050+20*.8*.001];bars=ax.bar([0,1,2],cost,width=.54,color=[C['line'],C['teal'],C['blue']]);ax.set(xticks=[0,1,2],xticklabels=['端侧','附近工作站','云地域'],ylabel='完整声明费用 / 教学单位',ylim=(0,.106));ax.set_title('同一质量与输入字节，先筛时限',loc='left',fontsize=13)
for bar,v,label in zip(bars,cost,['64 s：超期','41 s：可行','47 s：超期']):
 ax.text(bar.get_x()+bar.get_width()/2,v+.002,f'{v:.3f}',ha='center',fontsize=11);ax.text(bar.get_x()+bar.get_width()/2,.095,label,ha='center',fontsize=10)
f.text(.10,.055,'右图按云上行 6.4 Mbit/s；无额外排队与故障，价格和服务时间均为教学输入。',fontsize=10,color=C['muted'])
save(f,'figure-12-7-deployment');data['12-7']={'kind':'new_teaching_extension_not_measurement','rounds':20,'image_MB':.8,'local_other_s':.3,'model_s':[2.9,1.5,.8],'prepare_s':[0,3,1],'RTT_s':[0,.02,.2],'uplink_Mbps':[None,80,6.4],'task_seconds':[64,41,47],'cost_units':cost,'deadline_s':45,'feasible_threshold_Mbps':128/18,'faster_threshold_Mbps':128/14,'scan_Mbps':b.tolist(),'cloud_seconds':cloud.tolist()}
(HERE/'figure-data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
(HERE/'figure-layout-check.json').write_text(json.dumps({'text_extent_warnings':layout},ensure_ascii=False,indent=2)+'\n')
# HTML contains images, mathematical markup and font bytes; source links stay repository-relative.
md=HERE.parent/'12-端边云协同.md';raw=md.read_text();maths=[]
def protect(match):
 text=match[0];display=text.startswith('$$');latex=text[2:-2] if display else text[1:-1];token=f'MATHPLACEHOLDER{len(maths)}END';maths.append({'latex':latex.strip(),'display':display,'token':token});return '\n\n'+token+'\n\n' if display else token
protected=re.sub(r'\$\$[\s\S]*?\$\$|\$[^$\n]+\$',protect,raw)
body=markdown.markdown(protected,extensions=['tables','footnotes','fenced_code','toc'],output_format='html')
katex=ROOT/'manuscripts/ch06/vendor/katex'
node="const fs=require('fs'),k=require(process.argv[1]);const a=JSON.parse(fs.readFileSync(0,'utf8'));process.stdout.write(JSON.stringify(a.map(x=>k.renderToString(x.latex,{displayMode:x.display,throwOnError:true,output:'htmlAndMathml'}))))"
res=subprocess.run(['node','-e',node,str(katex/'katex.js')],input=json.dumps(maths),text=True,capture_output=True)
if res.returncode:raise SystemExit(res.stderr)
for entry,rendered in zip(maths,json.loads(res.stdout)):
 body=body.replace('<p>'+entry['token']+'</p>',rendered) if entry['display'] else body.replace(entry['token'],rendered)
math_css=(katex/'katex.min.css').read_text()
def font_url(m):
 p=katex/m[1];return 'url(data:font/'+p.suffix[1:]+';base64,'+base64.b64encode(p.read_bytes()).decode()+')'
math_css=re.sub(r'url\((fonts/[^)]+)\)',font_url,math_css)
body=re.sub(r'<table>(.*?)</table>',r'<div class="table-scroll"><table>\1</table></div>',body,flags=re.S)
body=re.sub(r'<p>(<img [^>]+>)</p>\s*<p><em>(图 12-[\s\S]*?)</em></p>',r'<figure>\1<figcaption>\2</figcaption></figure>',body)
for p in outputs:
 if p.suffix=='.svg':body=body.replace('src="ch12/'+p.name+'"','src="data:image/png;base64,'+base64.b64encode(p.with_suffix('.png').read_bytes()).decode()+'"')
css='''*{box-sizing:border-box}body{margin:0;background:#f7f7f4;color:#243640;font:18px/1.95 Georgia,"Songti SC",serif}main{max-width:1020px;margin:auto;padding:48px 46px 85px;background:#fff}h1,h2,h3{font-family:Arial,"PingFang SC",sans-serif;line-height:1.45;color:#183949}h1{font-size:36px}h2{font-size:28px;border-top:1px solid #d5e1e4;margin-top:65px;padding-top:26px}h3{font-size:23px;margin-top:38px}a{color:#286b98;text-underline-offset:3px;overflow-wrap:anywhere}figure{margin:30px 0}img{display:block;width:100%;height:auto;margin:0 auto 10px}figcaption{font:15px/1.85 Arial,"PingFang SC",sans-serif;color:#546e7a}table{border-collapse:collapse;width:100%;font-size:15px;line-height:1.7;margin:22px 0}td,th{padding:10px 12px;border-bottom:1px solid #d5e1e4;text-align:left}th{background:#edf4f6}code{font:0.85em/1.6 Menlo,monospace;background:#f0f4f6;overflow-wrap:anywhere}pre{overflow-x:auto;padding:16px;max-width:100%}nav{font:16px/1.9 Arial,"PingFang SC",sans-serif;background:#eff5f7;padding:18px 24px}nav a{display:block}.footnote{font-size:14px;line-height:1.8}.footnote li{margin-bottom:13px}.table-scroll{overflow-x:auto;max-width:100%}.katex{font-size:1.04em}.katex-display{overflow-x:auto;overflow-y:hidden;padding:12px 0}@media(max-width:650px){main{padding:24px 18px}body{font-size:17px}h1{font-size:29px}h2{font-size:25px}h3{font-size:21px}}@media print{main{max-width:none;padding:0}h2,h3{break-after:avoid}figure{break-inside:avoid}body{font-size:11pt}}'''
nav=''.join('<a href="#'+ident+'">'+title+'</a>' for ident,title in re.findall(r'<h2 id="([^"]+)">([^<]+)</h2>',body))
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>第 12 章 端边云协同</title><style>'+css+math_css+'</style></head><body><main><nav aria-label="本章目录">'+nav+'</nav>'+body+'</main></body></html>'
hp=md.with_suffix('.html');hp.write_text(page)
(HERE/'math-validation.json').write_text(json.dumps({'renderer':'KaTeX 0.16.11','expressions':len(maths),'display_expressions':sum(x['display'] for x in maths),'errors':[]},indent=2)+'\n')
artifacts=outputs+[HERE/'figure-data.json',hp,md]
(HERE/'manifest.json').write_text(json.dumps({'chapter':12,'generator':'manuscripts/ch12/build.py','figures':7,'font_family':family,'outputs':[{'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in artifacts]},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'figures':7,'maths':len(maths),'layout_warnings':len(layout),'html':str(hp)},ensure_ascii=False))
