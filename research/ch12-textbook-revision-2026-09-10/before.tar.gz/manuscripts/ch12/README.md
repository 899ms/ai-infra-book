# 第十二章正文与配图

[阅读版 HTML](../12-端边云协同.html) · [正文 Markdown](../12-端边云协同.md) · [写作大纲](../../outlines/12-端边云协同.md)

正文按六节、20 个小节展开，包含定量例题、反例、完整部署决策表与八项练习。先建立图片、语音和截图循环的时间预算，再比较分工、协议、无线与恢复；Queqiao 用于检验基线和归因，跨地域计算用于检查条件翻转。

七幅原创插图提供 SVG、PNG 和 PDF。图号、完整图题与说明均位于图片外；图内仅含面板说明、对象、图例与单位。HTML 内嵌图片、数学公式和公式字体，可离线阅读，外部来源链接仍指向仓库。手机可缩放页面；独立 SVG／PDF 适合放大或出版使用。

| 图 | 内容 | SVG | PNG | PDF |
|---|---|---|---|---|
| 12-1 | 上行速率与完整成片时间 | [SVG](figure-12-1-raw.svg) | [PNG](figure-12-1-raw.png) | [PDF](figure-12-1-raw.pdf) |
| 12-2 | 晚到块与后续播放时序 | [SVG](figure-12-2-paths.svg) | [PNG](figure-12-2-paths.png) | [PDF](figure-12-2-paths.pdf) |
| 12-3 | 压缩图片与完整特征发送时间 | [SVG](figure-12-3-placement.svg) | [PNG](figure-12-3-placement.png) | [PDF](figure-12-3-placement.pdf) |
| 12-4 | 交付依赖与音频完成时间 | [SVG](figure-12-4-transport.svg) | [PNG](figure-12-4-transport.png) | [PDF](figure-12-4-transport.pdf) |
| 12-5 | 固定开销与无线交换时间 | [SVG](figure-12-5-wireless.svg) | [PNG](figure-12-5-wireless.png) | [PDF](figure-12-5-wireless.pdf) |
| 12-6 | 相同纵轴下的 Queqiao 基线比较 | [SVG](figure-12-6-queqiao.svg) | [PNG](figure-12-6-queqiao.png) | [PDF](figure-12-6-queqiao.pdf) |
| 12-7 | 部署时间与两个带宽边界 | [SVG](figure-12-7-deployment.svg) | [PNG](figure-12-7-deployment.png) | [PDF](figure-12-7-deployment.pdf) |

## 来源与重建

[阅读记录](reading-notes.md)说明 calculations、survey、协议、案例和已有实验的实际采用范围。[sources.json](sources.json)锁定来源，[figure-data.json](figure-data.json)保存图数据及条件，[manifest.json](manifest.json)保存输出校验值。正文明确区分固定形状计算、教学参数与已有实测，没有新执行模型、网络或设备性能实验。

在仓库根目录运行：

```sh
python3 -m venv /tmp/ch12-book-venv
/tmp/ch12-book-venv/bin/pip install -r manuscripts/ch12/requirements.txt
/tmp/ch12-book-venv/bin/python manuscripts/ch12/build.py
/tmp/ch12-book-venv/bin/python manuscripts/ch12/verify.py
```

生成需要 Node.js 与中文字体，默认使用 macOS Arial Unicode 或 Linux Noto CJK，也可传 `--font /path/to/font`。KaTeX 0.16.11 复用仓库的 `manuscripts/ch06/vendor/katex` 及原有许可证；其生成结果和字体均已嵌入 HTML。来源变化时构建停止，先审阅变化再更新来源锁。

## 校验与预览

[内容与数据校验](validation.json)检查小节、练习、外部图注、来源与输出 SHA-256、本地链接、图片文本与主要算式。[公式检查](math-validation.json)记录 KaTeX 的严格解析结果。[练习算术核对](exercise-check.json)提供关键数值，不替代开放式解释题的讨论。

[浏览器检查](browser-validation.json)覆盖 1440 px 桌面与 390 px 手机，检查图片加载、公式、目录锚点和横向溢出。[插图总览](preview-figures.png)、[桌面图文](preview-desktop-raw.png)、[手机正文](preview-mobile.png)。七幅插图已逐图目视检查，图例和标签无裁切，所有图片内部均无图号。

可选浏览器复验需要 Playwright 和本地 Chromium／Chrome：

```sh
/tmp/ch12-book-venv/bin/pip install playwright
/tmp/ch12-book-venv/bin/python manuscripts/ch12/browser-check.py --executable '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
```

## 数字论证与配图修订

本次按条件、推导、结论与下一项问题重写全章。配置形状与整数边界保留精确值，性能和成本采用能解释选择的精度。七幅主图各用一组坐标突出一个关系；播放设备记录、双连接故障及精确统计移入[配套证据说明](evidence-notes.md)和脚注。[修订记录](../../research/ch12-prose-revision-2026-09-10/README.md)保存图文调整及旧稿归档位置。
