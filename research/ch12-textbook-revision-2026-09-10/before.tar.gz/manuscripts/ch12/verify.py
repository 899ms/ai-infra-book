#!/usr/bin/env python3
"""Validate chapter structure, actual source data, links, artwork, and arithmetic."""
from pathlib import Path
from fractions import Fraction
from urllib.parse import unquote, urlsplit
import hashlib,json,re,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
md=ROOT/'manuscripts/12-端边云协同.md';text=md.read_text();page=md.with_suffix('.html').read_text();errors=[];checks={}
def check(name,condition):
 checks[name]=bool(condition)
 if not condition:errors.append(name)
def close(x,y):return abs(x-y)<1e-8
outline=(ROOT/'outlines/12-端边云协同.md').read_text()
check('six_sections',re.findall(r'^## (12\.\d+) ',text,re.M)==[f'12.{i}' for i in range(1,7)])
check('twenty_subsections_match_outline',re.findall(r'^### .+$',text,re.M)==re.findall(r'^### .+$',outline,re.M))
check('eight_exercises',re.findall(r'^\*\*(12-\d+)\s',text,re.M)==[f'12-{i}' for i in range(1,9)])
check('three_core_exercises',re.findall(r'^\*\*(12-\d+)[^\n]*〔核心',text,re.M)==['12-2','12-3','12-7'])
check('seven_external_captions',re.findall(r'^\*图 (12-\d+)：',text,re.M)==[f'12-{i}' for i in range(1,8)])
check('seven_html_figcaptions',page.count('<figcaption>')==7)
check('seven_embedded_images',page.count('src="data:image/png;base64,')==7)
check('no_math_placeholders','MATHPLACEHOLDER' not in page)
check('no_katex_errors','class="katex-error"' not in page)
check('no_authoring_placeholders',not re.search('配图计划|待扩写|TODO|TBD',text))
# Source and artifact hashes are checked independently of the drawing code.
for record in json.loads((HERE/'sources.json').read_text())['sources']:
 p=ROOT/record['path'];check('source:'+record['path'],p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==record['sha256'])
for record in json.loads((HERE/'manifest.json').read_text())['outputs']:
 p=ROOT/record['path'];check('artifact:'+record['path'],p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==record['sha256'])
links=re.findall(r'\]\(([^)]+)\)',text)
for url in links:
 parts=urlsplit(url)
 if parts.scheme or not parts.path:continue
 p=(md.parent/unquote(parts.path)).resolve();check('link:'+url,p.exists())
for p in HERE.glob('figure-*.svg'):
 tree=ET.parse(p);labels=[''.join(x.itertext()) for x in tree.iter() if x.tag.endswith('}text')]
 check('artwork_has_no_caption_number:'+p.name,not any(re.search(r'图\s*\d+\s*[-－–]\s*\d+',s) for s in labels))
 check('artwork_has_labels:'+p.name,len(labels)>5)
check('no_layout_warnings',json.loads((HERE/'figure-layout-check.json').read_text())['text_extent_warnings']==[])
d=json.loads((HERE/'figure-data.json').read_text());q=json.loads((ROOT/'calculations/results/queqiao-records-conditions.json').read_text());ec=json.loads((ROOT/'calculations/results/multimodal-cache-single.json').read_text())['summary']
check('full_ec_shape',400*10240*2==ec['complete_encoder_bytes_per_image']==d['12-3']['bytes'][1])
check('visual_kv',400*147456==ec['visual_kv_bytes_per_image']==d['12-3']['bytes'][2])
check('image_feature_transfer',d['12-3']['uplink_seconds_at_6_4Mbps'][:2]==[1,10.24])
check('raw_budget',close(30*8/20+.1+.3+5*8/100,12.8))
check('model_acceleration',close(12+.1+.03+.4,12.53))
check('compression_budget',close(15*8/20+.1+.3+.4+.15,6.95))
check('screenshot_round',close(.2*8/6.4+.03+2.5,2.78))
check('screenshot_30_round_saving',close((3.5-2.78)*30,21.6))
check('migration_break_even',19*.4 < 64*2**20*8/80e6+1 <20*.4)
check('raw_packet_wire',35000000+29966*(60+92)==39554832)
check('ack_difference_bytes',39555120-38177328==1377792)
check('ack_difference_time',close(14.564459796-14.52103724,.043422556))
check('air_exchange_totals',all(close(sum(a),b) for a,b in zip(d['12-5']['exchange_components_us'],[302,134])))
check('airtime_budget',close(30800*(302+134)/1e6,13.4288))
check('fixed_file_payload',d['12-6']['recorded_fixed_bytes']==354640)
check('queqiao_matched_rows',d['12-6']['matched_ASR_ms']==[[1185.3,301.6],[240.9,236.5]])
check('all_physical_rows_retained',d['12-6']['starvation_ms']==[[520,360],[700,1040],[460,560],[880,1440]])
check('deployment_times',all(close(x,y) for x,y in zip(d['12-7']['task_seconds'],[20*(.3+2.9),3+20*(.3+1.5+.02+6.4/80),1+20*(.3+.8+.2+6.4/6.4)])))
check('deployment_thresholds',close(27+128/d['12-7']['feasible_threshold_Mbps'],45) and close(27+128/d['12-7']['faster_threshold_Mbps'],41))
check('deployment_cost',close(d['12-7']['cost_units'][2],.05+16*.001))
for name,c in d['12-4']['comparisons'].items():
 for source,values in zip(c['sources'],c['image_audio_seconds']):
  b={x['id']:float(Fraction(x['complete'])) for x in json.loads((ROOT/'calculations/results'/f'{source}.json').read_text())['businesses']}
  check('media_saved_values:'+source,values==[b['image'],b['audio']])
check('no_control_characters',all(ord(c)>=32 or c=='\n' for c in text))
expected_subsets=['three_latency_curves','first_five_audio_chunks','image_and_complete_ec_only','delivery_order_only','exchange_components_only','matched_ASR_only','latency_thresholds_only']
for i,subset in enumerate(expected_subsets,1):
 check('single_relationship:'+str(i),d[f'12-{i}']['plotted_subset']==subset and d[f'12-{i}']['axes_count']==1)
check('screenshot_integer_boundary',37*2.78<105<38*2.78)
check('preparation_amortization',6*.5==3 and 10*.5-3==2)
check('buffer_depletion',.12<15360/(256000-130000)<.13)
check('deployment_examples',27+128/8==43 and close(27+128/10,39.8))
check('rounded_queqiao_prose','约 0.24 s | 约 0.24 s' in text)
# A compact arithmetic answer key verifies that the newly specified exercises have determinate inputs.
answers={'12-1':{'compression_break_even_Mbps':120/.15,'only_0_2_s_accelerated_total_s':12.8-.2+.02},'12-2':{'compressed_38_rounds_s':38*2.78,'largest_faster_integer_rounds':37},'12-3':{'extra_edge_encoding_s':.12+10.24-(1+.04),'migration_preparation_s':64*2**20*8/80e6+1},'12-5':{'ideal_airtime_saved_s':15400*134/1e6,'buffer_depletion_s':(.06*256000)/(256000-130000)},'12-6':{'ideal_split_fraction':2/3,'ideal_seconds':30*8/30,'shared_bottleneck_lower_s':30*8/24,'joint_failure':.02+.98*.1*.05},'12-8':{'ten_rounds_times_s':[32,22,24],'ten_rounds_cost':[.03,.04,.025+.008],'ten_rounds_cloud_double_rate_cost':.025+.016}}
(HERE/'exercise-check.json').write_text(json.dumps(answers,ensure_ascii=False,indent=2)+'\n')
report={'passed':not errors,'checks':len(checks),'sections':6,'subsections':20,'figures':7,'exercises':8,'sources':len(json.loads((HERE/'sources.json').read_text())['sources']),'local_links':len(links),'chinese_characters':len(re.findall(r'[\u4e00-\u9fff]',text)),'errors':errors}
(HERE/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2));raise SystemExit(bool(errors))
